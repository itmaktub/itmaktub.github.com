/**
  ******************************************************************************
  * @file    main.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "freertos.h"
#include "task.h"
#include "queue.h"
#include "stdio.h"
#include "led.h"
#include "UART.h"
#include "stm32f10x_usart.h"
#include "GUI.h"
#include "lcd_r1509.h"
#include "WM.h"
#include "lcd.h"
#include "GUIDEMO.h"
#include "TouchScreen.h"
#include "WindowDLG_Test.h"


static uint32_t count = 0;

static uint32_t used_mem = 0;
static uint32_t free_mem = 0;

#define Background_Task_PRIO    ( tskIDLE_PRIORITY  + 10 )  //
#define Normal_Task_STACK   ( 512 )
#define RECOMMENDED_MEMORY (1024L * 10)                     //����������ǰ���ʣ���ڴ��Ƿ���

/* ʹ���˼�����������̬������Ҫ����������  1 ���� 0 �ر�*/
#define LED_TASK_ENABLE                 (1)     /* led��˸���� */
#define LCD_TOUCH_TASK_ENABLE           (1)     /* �������ɼ���������ռ�ռ������ */

#define LCD_TESTWINDOWS_TASK_ENABLE     (0)     /* �Լ����Ĵ������� */
#define LCD_DEMO_TASK_ENABLE            (1)     /* �ٷ�DEMO��ʾ���� */
#define LCD_TOUCH_TEST_TASK_ENABLE      (0)     /* ������У׼�������� */


/* led��˸���� */
#if LED_TASK_ENABLE
static void vLED_Task(uint8_t parametra)
{
	while(1)
	{
		Led_On(parametra);
		vTaskDelay(500/portTICK_RATE_MS);
		Led_Off(parametra);
		vTaskDelay(500/portTICK_RATE_MS);
		printf("LED %d ",parametra);
		printf("RunCount: %d \r\n",count);
		count ++;
	}
}
#endif


/* ������ˢ������ �ͼ���ռ�ռ�õ����� */
#if LCD_TOUCH_TASK_ENABLE
static void vLCD_Touch_Task(void)
{
    static uint8_t tick_count = 0;
    SysTick_Config(SystemCoreClock / 1000);

    while(1)
    {
        GUI_TOUCH_Exec();
        if(tick_count ++ > 100)
        {
            used_mem = GUI_ALLOC_GetNumUsedBytes();
            free_mem = GUI_ALLOC_GetNumFreeBytes();
            printf("used: %f %% \r\n",(float) used_mem/(used_mem + free_mem));
            tick_count = 0;
        }
            

        GUI_Delay(10);
    }
}
#endif


/* �ٷ�demo */
#if LCD_DEMO_TASK_ENABLE
static void vLCD_Demo_Task(void)
{
    SysTick_Config(SystemCoreClock / 1000);
        
    #if GUI_WINSUPPORT
        WM_SetCreateFlags(WM_CF_MEMDEV);
    #endif
        GUI_Init();
        
    #if GUI_WINSUPPORT
        WM_MULTIBUF_Enable(1);
    #endif
    /* Start Demo */
    while(1)
    {
        GUIDEMO_Main();
    }
}
#endif

/* ���ڲ������� */
#if LCD_TESTWINDOWS_TASK_ENABLE
static void vLCD_TestWindows_Task(void)
{
    
    #if GUI_WINSUPPORT
        WM_SetCreateFlags(WM_CF_MEMDEV);
    #endif
    
    GUI_Init();
        
    #if GUI_WINSUPPORT
        WM_MULTIBUF_Enable(1);
    #endif
    
    GUI_SetBkColor(GUI_BLUE);
    GUI_SetColor(GUI_BLACK);
    GUI_Clear();
    
    GUI_CURSOR_Show();
//    WM_SetCreateFlags(WM_CF_MEMDEV);       /* Automatically use memory devices on all windows */   
    CreateWindow();
  
    while(1)
    {
        WM_Exec();												 //��Ļˢ��
        GUI_Delay(100);
    }
}
#endif


/* ������У׼�������� */
#if LCD_TOUCH_TEST_TASK_ENABLE
void vLCD_Touch_Test_Task(void)
{
  GUI_PID_STATE TouchState;
  int xPhys;
  int yPhys;

  GUI_Init();
  //
  // Check if recommended memory for the sample is available
  //
  if (GUI_ALLOC_GetNumFreeBytes() < RECOMMENDED_MEMORY) {
    GUI_ErrorOut("Not enough memory available."); 
    return;
  }
  GUI_CURSOR_Show();
  GUI_CURSOR_Select(&GUI_CursorCrossL);
  GUI_SetBkColor(GUI_WHITE);
  GUI_SetColor(GUI_BLACK);
  GUI_Clear();
  GUI_DispString("Measurement of\nA/D converter values");
  while (1) 
  {
    GUI_TOUCH_GetState(&TouchState);  // Get the touch position in pixel
    xPhys = GUI_TOUCH_GetxPhys();     // Get the A/D mesurement result in x
    yPhys = GUI_TOUCH_GetyPhys();     // Get the A/D mesurement result in y
    //
    // Display the measurement result
    //
    GUI_SetColor(GUI_BLUE);
    GUI_DispStringAt("Analog input:\n", 0, 20);
    GUI_GotoY(GUI_GetDispPosY() + 2);
    GUI_DispString("x:");
    GUI_DispDec(xPhys, 4);
    GUI_DispString(", y:");
    GUI_DispDec(yPhys, 4);
    //
    // Display the according position
    //
    GUI_SetColor(GUI_RED);
    GUI_GotoY(GUI_GetDispPosY() + 4);
    GUI_DispString("\nPosition:\n");
    GUI_GotoY(GUI_GetDispPosY() + 2);
    GUI_DispString("x:");
    GUI_DispDec(TouchState.x,4);
    GUI_DispString(", y:");
    GUI_DispDec(TouchState.y,4);
    //
    // Wait a while
    //
    GUI_Delay(100);
  }
}
#endif


/* Ӳ����ʼ������ */
void prvSetupHardware( void )
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, ENABLE);
    Led_Init();
    UART1_init(72,9600);
    tp_Config();                            //����������
}


/* ������ */
int main(void)
{
    prvSetupHardware();

#if LED_TASK_ENABLE
    xTaskCreate( (TaskFunction_t) vLED_Task,  "LED_A", configMINIMAL_STACK_SIZE,  (void *) LED_A, tskIDLE_PRIORITY + 1, NULL );
    xTaskCreate( (TaskFunction_t) vLED_Task,  "LED_B", configMINIMAL_STACK_SIZE,  (void *) LED_B, tskIDLE_PRIORITY + 1, NULL );
    xTaskCreate( (TaskFunction_t) vLED_Task,  "LED_C", configMINIMAL_STACK_SIZE,  (void *) LED_C, tskIDLE_PRIORITY + 1, NULL );
#endif
    
#if LCD_TOUCH_TASK_ENABLE
    xTaskCreate( (TaskFunction_t) vLCD_Touch_Task,  "Screen Touch", Normal_Task_STACK, NULL, tskIDLE_PRIORITY + 8, NULL );
#endif
    
#if LCD_DEMO_TASK_ENABLE
    xTaskCreate( (TaskFunction_t) vLCD_Demo_Task,  "LCD Demo", Normal_Task_STACK, NULL, tskIDLE_PRIORITY + 9, NULL );
#endif
    
#if LCD_TOUCH_TEST_TASK_ENABLE
    xTaskCreate( (TaskFunction_t) vLCD_Touch_Test_Task,  "LCD Touch Test", Normal_Task_STACK, NULL, tskIDLE_PRIORITY + 9, NULL );
#endif

#if LCD_TESTWINDOWS_TASK_ENABLE
    xTaskCreate( (TaskFunction_t) vLCD_TestWindows_Task,  "LCD Windows Test", Normal_Task_STACK, NULL, tskIDLE_PRIORITY + 9, NULL );
#endif

    /* Start the scheduler. */
    vTaskStartScheduler(); 
    return 0;
}


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  while (1)
  {}
}

#endif
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
