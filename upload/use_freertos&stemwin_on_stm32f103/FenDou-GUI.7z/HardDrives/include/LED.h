#ifndef _LED_H_
#define _LED_H_

#include "stdint.h"

#define LED_A	0
#define LED_B	1
#define LED_C	2

#define LedA_on    GPIO_SetBits(GPIOB, GPIO_Pin_5)
#define LedA_off   GPIO_ResetBits(GPIOB, GPIO_Pin_5)


#define LedB_on    GPIO_SetBits(GPIOD, GPIO_Pin_6)
#define LedB_off   GPIO_ResetBits(GPIOD, GPIO_Pin_6)


#define LedC_on    GPIO_SetBits(GPIOD, GPIO_Pin_3)
#define LedC_off   GPIO_ResetBits(GPIOD, GPIO_Pin_3)


void Led_Init(void);
void Led_On(uint8_t n);
void Led_Off(uint8_t n);

#endif /* #define _LED_H_ */
