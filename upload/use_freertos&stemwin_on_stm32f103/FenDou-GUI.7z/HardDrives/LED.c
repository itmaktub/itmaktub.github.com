#include "stm32f10x.h"
#include "led.h"


void Led_Init(void) 
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOD , ENABLE); 						 

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3 | GPIO_Pin_6;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
    	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);//�ر�JATG,ǧ���ܹر�SWD������оƬ���ϣ��ײ�!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}

void Led_On(uint8_t n)
{
	switch (n) 
	{
		case LED_A: LedA_on; break;
		case LED_B: LedB_on; break;
		case LED_C: LedC_on; break;
		default: break;
	}
}

void Led_Off(uint8_t n) 
{
	switch (n) 
	{
		case LED_A: LedA_off; break;
		case LED_B: LedB_off; break;
		case LED_C: LedC_off; break;
		default: break;
	}
}


